<?php
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<html>
<head>
<Title>Free Hosting</Title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>
<body>
<table border="1" align="center" style="width:100%;height:auto;"><tr>
<th><a href="https://www.net2ftp.com/index.php">FTP</a></th><th><a href="https://db4free.net">SQL</a></th>
</tr></table>
<table border="1" align="center" style="width:100%;height:auto;"><tr>
<td align="right"><a href="http://cpanel.<?echo $yourdomain;?>">Log In</a></td>
</tr></table>
<table border="1" align="center" style="width:100%;height:auto;"><tr>
<td><form method=post action="http://order.<?echo $yourdomain;?>/register2.php"><br>
<input placeholder="Sub-Domain" type=text name=username value="<?echo $domain;?>" pattern="[a-z0-9]{4,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter subdomain')" oninput="setCustomValidity('')" required>.<?echo $yourdomain;?><br>
<input placeholder="Your Password" type=password name=password id=reg_passwd pattern=".{6,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter password')" oninput="setCustomValidity('')" required><br>
<input placeholder="E-mail Address" type=text name=email pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" oninvalid="this.setCustomValidity('Enter e-mail address')" oninput="setCustomValidity('')" required><br>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<img src="http://order.<? echo $yourdomain;?>/image.php?id=<?PHP echo $id; ?>"><br>
<input placeholder="Security Code" type=text pattern=".{5,5}" name=number oninvalid="this.setCustomValidity('Enter security code')" oninput="setCustomValidity('')" required><br>
<button type="submit">Sign Up</button></td>
</tr></table>
<table border="1" align="center" style="width:100%;height:auto;"><tr>
<td align="right">&copy; 2024</td>
</tr></table>
<?php include 'stat.php'; ?>
</body>
</html>

