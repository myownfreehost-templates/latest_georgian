<?php
define("_TITLE", "ვებ-საიტის შექმნა");
define("_DESCRIPTION_1", "უფასო ვებ-ჰოსტინგი 5GB სივრცით, ულიმიტო ტრაფიკით, 24 საათში 50 000 მაქსიმალური hits და php მხარდაჭერით, უფასო ქვე-დომენი&nbsp;");
define("_DESCRIPTION_2", "&nbsp;dns ჩანაწერებით CNAME და SPF მხარდაჭერით.");
define("_WHAT_IS_THIS", "რა არის ეს?");
define("_ABOUT_THIS_WEBSITE", "ჩვენი სერვისი არის სისტემა რომელიც საშუალებას გაძლევთ შექმნათ საკმაოდ მძლავრი და ფუნქციონალური ვებ-საიტი პირდაპირ თქვენი მოწყობილობიდან სრულიად უფასოდ.");
define("_USERNAME", "მომხმარებელი");
define("_PASSWORD", "პაროლი");
define("_SHOW", "&nbsp;ნახვა");
define("_REMEMBER", "დამახსოვრება");
define("_SIGNIN", "შესვლა");
define("_LOST_YOUR_PASSWORD", "დაგავიწყდათ პაროლი?");
define("_SUBDOMAIN", "ვებ მისამართი");
define("_EMAIL", "ელ. ფოსტა");
define("_CODE", "უსაფრთხოების კოდი");
define("_SIGNUP", "რეგისტრაცია");
define("_SITE_MANAGEMENT", "საიტის კონტროლი");
define("_REGISTRATION", "საიტის რეგისტრაცია");
