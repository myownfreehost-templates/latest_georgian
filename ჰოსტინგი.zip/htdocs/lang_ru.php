<?php
define("_TITLE", "Создать веб-сайт");
define("_DESCRIPTION_1", "Бесплатный веб-хостинг с 5 ГБ пространства, неограниченным трафиком, максимальным количеством посещений 50 000 за 24 часа и поддержкой php, бесплатным поддоменом&nbsp;");
define("_DESCRIPTION_2", "&nbsp;dns с поддержкой записей CNAME и SPF.");
define("_WHAT_IS_THIS", "Что это?");
define("_ABOUT_THIS_WEBSITE", "Наш сервис представляет собой систему, которая позволяет вам совершенно бесплатно создать достаточно мощный и функциональный сайт прямо с вашего устройства.");
define("_USERNAME", "Имя пользователя");
define("_PASSWORD", "Пароль");
define("_SHOW", "&nbsp;Показать");
define("_REMEMBER", "Запомнить");
define("_SIGNIN", "Войти");
define("_LOST_YOUR_PASSWORD", "Забыли свой пароль?");
define("_SUBDOMAIN", "Веб-адрес");
define("_EMAIL", "Эл. почта");
define("_CODE", "Код безопасности");
define("_SIGNUP", "Регистрация");
define("_SITE_MANAGEMENT", "Управление веб-сайтом");
define("_REGISTRATION", "Создание веб-сайта");
