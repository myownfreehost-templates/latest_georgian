<?php
define("_TITLE", "Create A Website");
define("_DESCRIPTION_1", "Free web hosting with 5GB space, unlimited traffic, 50,000 max hits in 24 hours and php support, free sub-domain&nbsp;");
define("_DESCRIPTION_2", "&nbsp;dns with CNAME and SPF records support.");
define("_WHAT_IS_THIS", "What is this?");
define("_ABOUT_THIS_WEBSITE", "Our service is a system that allows you to create quite powerful and functional website directly from your device completely free of charge.");
define("_USERNAME", "Username");
define("_PASSWORD", "Password");
define("_SHOW", "&nbsp;show");
define("_REMEMBER", "Remember");
define("_SIGNIN", "Sign In");
define("_LOST_YOUR_PASSWORD", "Lost your password?");
define("_SUBDOMAIN", "Web Address");
define("_EMAIL", "E-mail");
define("_CODE", "Security Code");
define("_SIGNUP", "Sign Up");
define("_SITE_MANAGEMENT", "Site management");
define("_REGISTRATION", "Site registration");
