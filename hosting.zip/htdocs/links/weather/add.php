<?php
$link = $_POST['link'];
$fp = fopen('weather.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
