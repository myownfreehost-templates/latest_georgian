<?php
$link = $_POST['link'];
$fp = fopen('shop.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
