<?php
$link = $_POST['link'];
$fp = fopen('animals.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
