<?php
$link = $_POST['link'];
$fp = fopen('dating.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
