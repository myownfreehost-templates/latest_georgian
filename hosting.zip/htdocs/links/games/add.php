<?php
$link = $_POST['link'];
$fp = fopen('games.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
<html>
<?php
header('Location: index.php');
exit;
?>
