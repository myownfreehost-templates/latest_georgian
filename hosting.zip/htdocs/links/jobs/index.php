<form action='jobs/add.php' method='POST'>
<input type='url' value='<?php
echo file_get_contents('jobs/jobs.txt');
?>' placeholder="Link" name='link' required><button type="submit">Submit</button> 
</form>
