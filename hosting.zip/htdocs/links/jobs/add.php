<?php
$link = $_POST['link'];
$fp = fopen('jobs.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
