<?php
$link = $_POST['link'];
$fp = fopen('culinary.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
