<?php
$link = $_POST['link'];
$fp = fopen('kids.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
