<?php
$link = $_POST['link'];
$fp = fopen('media.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
