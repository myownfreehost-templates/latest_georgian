<?php
$link = $_POST['link'];
$fp = fopen('directory.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
