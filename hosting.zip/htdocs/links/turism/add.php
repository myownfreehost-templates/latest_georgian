<?php
$link = $_POST['link'];
$fp = fopen('turism.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
