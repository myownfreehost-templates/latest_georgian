<?php
$link = $_POST['link'];
$fp = fopen('auto.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
