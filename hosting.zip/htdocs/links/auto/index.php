<form action='auto/add.php' method='POST'>
<input type='url' value='<?php
echo file_get_contents('auto/auto.txt');
?>' placeholder="Link" name='link' required><button type="submit">Submit</button> 
</form>
