<form action='service/add.php' method='POST'>
<input type='url' value='<?php
echo file_get_contents('service/service.txt');
?>' placeholder="Link" name='link' required><button type="submit">Submit</button> 
</form>
