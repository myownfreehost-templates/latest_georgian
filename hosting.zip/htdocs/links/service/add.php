<?php
$link = $_POST['link'];
$fp = fopen('service.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
