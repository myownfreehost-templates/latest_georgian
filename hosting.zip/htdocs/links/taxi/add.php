<?php
$link = $_POST['link'];
$fp = fopen('taxi.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
