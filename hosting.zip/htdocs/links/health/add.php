<?php
$link = $_POST['link'];
$fp = fopen('health.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
<html>
<?php
header('Location: index.php');
exit;
?>
